// Run with: node seed.js
// Populates the database with a couple of sample projects so the portfolio
// isn't empty the first time you load it.

require('dotenv').config();
const mongoose = require('mongoose');
const Project = require('./models/Project');

const sampleProjects = [
  {
    title: 'Personal Portfolio Website',
    description:
      'A full-stack portfolio site built with HTML/CSS/JS on the frontend and Node.js, Express, and MongoDB on the backend.',
    techStack: ['HTML', 'CSS', 'JavaScript', 'Node.js', 'Express', 'MongoDB'],
    githubUrl: 'https://github.com/your-username/portfolio-website',
    liveUrl: '',
    imageUrl: '',
    featured: true
  },
  {
    title: 'Task Manager App',
    description: 'A simple CRUD task manager for organizing daily to-dos, built to practice REST API design.',
    techStack: ['Node.js', 'Express', 'MongoDB'],
    githubUrl: '',
    liveUrl: '',
    imageUrl: '',
    featured: false
  }
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB');

    await Project.deleteMany({});
    await Project.insertMany(sampleProjects);

    console.log('Sample projects added successfully!');
    process.exit(0);
  } catch (err) {
    console.error('Seeding error:', err.message);
    process.exit(1);
  }
}

seed();
