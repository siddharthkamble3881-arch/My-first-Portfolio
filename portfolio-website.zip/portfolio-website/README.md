# Personal Portfolio Website

A full-stack personal portfolio project:

- **Frontend:** HTML, CSS, JavaScript (vanilla, no framework)
- **Backend:** Node.js + Express (REST API)
- **Database:** MongoDB (via Mongoose)

The frontend fetches projects from the backend API and lets visitors submit
messages through a contact form that's saved to MongoDB.

## Project Structure

```
portfolio-website/
├── backend/
│   ├── models/
│   │   ├── Project.js
│   │   └── Message.js
│   ├── routes/
│   │   ├── projects.js
│   │   └── messages.js
│   ├── server.js
│   ├── seed.js
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── index.html
    ├── css/style.css
    └── js/script.js
```

## 1. Run the Backend Locally

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` and set `MONGO_URI` to your MongoDB connection string. Easiest
option: create a free cluster at https://www.mongodb.com/cloud/atlas, add a
database user, allow your IP (or 0.0.0.0/0 for testing), and copy the
connection string it gives you.

Then start the server:

```bash
npm start
```

You should see `Connected to MongoDB` and `Server running on port 5000`.

Optional — add a couple of sample projects so the site isn't empty:

```bash
node seed.js
```

Test it's working by visiting `http://localhost:5000/api/projects` in your
browser — you should get a JSON array back.

## 2. Run the Frontend Locally

The frontend is plain static files, so you can open `frontend/index.html`
directly in a browser, or serve it (recommended, avoids CORS quirks) with:

```bash
cd frontend
npx serve .
```

or the VS Code "Live Server" extension. By default `js/script.js` points at
`http://localhost:5000/api` — matching the backend above.

## 3. Add / Manage Projects

Since there's no admin UI, manage projects directly via the API (e.g. with
`curl`, Postman, or Insomnia):

```bash
curl -X POST http://localhost:5000/api/projects \
  -H "Content-Type: application/json" \
  -d '{
    "title": "My Cool App",
    "description": "A short description of what it does.",
    "techStack": ["React", "Node.js", "MongoDB"],
    "githubUrl": "https://github.com/you/repo",
    "liveUrl": "https://your-app.vercel.app"
  }'
```

Full CRUD is available:
- `GET /api/projects` — list all
- `GET /api/projects/:id` — get one
- `POST /api/projects` — create
- `PUT /api/projects/:id` — update
- `DELETE /api/projects/:id` — delete

Contact messages are stored via `POST /api/messages` and can be viewed with
`GET /api/messages`.

## 4. Deploy

### Database — MongoDB Atlas
Already set up if you followed step 1. Just make sure network access allows
connections from your deployment platform (0.0.0.0/0 is simplest for a
student project).

### Backend — Render, Railway, or Heroku
Using **Render** (free tier, simplest today):
1. Push this repo to GitHub.
2. Create a new **Web Service** on https://render.com, point it at the repo,
   set the root directory to `backend`.
3. Build command: `npm install` — Start command: `npm start`.
4. Add environment variables `MONGO_URI` and `CLIENT_ORIGIN` (your deployed
   frontend URL, e.g. `https://your-site.netlify.app`) in Render's dashboard.
5. Deploy. Note the URL Render gives you, e.g. `https://your-api.onrender.com`.

Heroku and Railway follow the same pattern: point at the `backend` folder,
set the same environment variables, deploy.

### Frontend — Netlify or Vercel
1. In `frontend/js/script.js`, change `API_BASE_URL` to your deployed backend
   URL plus `/api`, e.g.:
   ```js
   const API_BASE_URL = 'https://your-api.onrender.com/api';
   ```
2. Push to GitHub (or drag-and-drop the `frontend` folder into Netlify's
   deploy UI at https://app.netlify.com/drop).
3. On Netlify/Vercel, set the base/root directory to `frontend` with no
   build command needed (it's static HTML/CSS/JS).
4. Deploy — you'll get a live URL like `https://your-name.netlify.app`.

Update the backend's `CLIENT_ORIGIN` env var to match this final URL so CORS
allows requests from it.

## Notes / Next Steps
- Replace "Your Name" and hero copy in `frontend/index.html` with your own info.
- Add your resume link, real project screenshots (`imageUrl` field), and social links.
- Consider adding basic auth to the `POST/PUT/DELETE /api/projects` routes
  before going fully public, so strangers can't edit your project list.
