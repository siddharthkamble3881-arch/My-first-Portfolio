// ---- Configuration ----
// Point this at your deployed backend URL, e.g. "https://your-api.onrender.com/api"
// While developing locally with the backend running on port 5000, leave as-is.
const API_BASE_URL = 'http://localhost:5000/api';

// ---- Mobile nav toggle ----
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

navLinks.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});

// ---- Footer year ----
document.getElementById('year').textContent = new Date().getFullYear();

// ---- Load projects from backend API ----
async function loadProjects() {
  const grid = document.getElementById('projectsGrid');

  try {
    const res = await fetch(`${API_BASE_URL}/projects`);
    if (!res.ok) throw new Error(`Server responded with ${res.status}`);

    const projects = await res.json();

    if (!projects.length) {
      grid.innerHTML = '<p class="loading-text">No projects yet. Add some via the API!</p>';
      return;
    }

    grid.innerHTML = projects.map(renderProjectCard).join('');
  } catch (err) {
    grid.innerHTML = `<p class="error-text">Couldn't load projects. Make sure the backend server is running at ${API_BASE_URL}.</p>`;
    console.error('Failed to load projects:', err);
  }
}

function renderProjectCard(project) {
  const tags = (project.techStack || [])
    .map((tech) => `<span class="tech-tag">${escapeHtml(tech)}</span>`)
    .join('');

  const links = `
    ${project.githubUrl ? `<a href="${project.githubUrl}" target="_blank" rel="noopener">GitHub</a>` : ''}
    ${project.liveUrl ? `<a href="${project.liveUrl}" target="_blank" rel="noopener">Live Demo</a>` : ''}
  `;

  return `
    <div class="project-card">
      <h3>${escapeHtml(project.title)}</h3>
      <p>${escapeHtml(project.description)}</p>
      <div class="tech-tags">${tags}</div>
      <div class="project-links">${links}</div>
    </div>
  `;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---- Contact form submission ----
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');

contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const payload = {
    name: document.getElementById('name').value.trim(),
    email: document.getElementById('email').value.trim(),
    message: document.getElementById('message').value.trim()
  };

  formStatus.textContent = 'Sending...';
  formStatus.style.color = 'var(--color-text-muted)';

  try {
    const res = await fetch(`${API_BASE_URL}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error('Failed to send message');

    formStatus.textContent = 'Message sent! Thanks for reaching out.';
    formStatus.style.color = '#4ade80';
    contactForm.reset();
  } catch (err) {
    formStatus.textContent = "Something went wrong. Please try again later.";
    formStatus.style.color = '#f87171';
    console.error(err);
  }
});

// ---- Init ----
loadProjects();
